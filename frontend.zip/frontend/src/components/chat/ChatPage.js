
import React, { Component } from "react";

class ChatPage extends Component {
    render() {
        return (
            <div>

            </div>
        );
    }
}

export default ChatPage;